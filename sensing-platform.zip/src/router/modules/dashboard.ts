import { $t } from "@/plugins/i18n";
import { dashboard } from "@/router/enums";
export default {
  path: "/dashboards",
  redirect: "/dashboards/watermark",
  meta: {
    icon: "icon-dashboards",
    title: $t("menus.dashboards"),
    rank: dashboard
  }
} as RouteConfigsTable;
