import { $t } from "@/plugins/i18n";

export default {
  path: "/menuoverflow",
  redirect: "/menuoverflow/index",
  meta: {
    title: $t("menus.hsMenuoverflow"),
    rank: 8,
    showLink: false
  },
  children: [
    {
      path: "/menuoverflow/index",
      name: "MenuOverflow",
      component: () => import("@/views/menuoverflow/index.vue"),
      meta: {
        title: $t("menus.hsChildMenuoverflow"),
      }
    }
  ]
} as RouteConfigsTable;
