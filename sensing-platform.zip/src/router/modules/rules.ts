import { $t } from "@/plugins/i18n";
import { rules } from "@/router/enums";
export default {
  path: "/rules",
  redirect: "/rules/watermark",
  meta: {
    icon: "icon-rules",
    title: $t("menus.rules"),
    rank: rules
  }
} as RouteConfigsTable;
