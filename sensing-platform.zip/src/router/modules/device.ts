import { $t } from "@/plugins/i18n";
import { device } from "@/router/enums";
export default {
  path: "/devices",
  redirect: "/device/watermark",
  meta: {
    icon: "icon-devices",
    title: $t("menus.devices"),
    rank: device
  }
} as RouteConfigsTable;
