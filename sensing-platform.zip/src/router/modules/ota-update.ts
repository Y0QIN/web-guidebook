import { $t } from "@/plugins/i18n";
import { otaUpdate } from "@/router/enums";
export default {
  path: "/otaUpdates",
  redirect: "/otaUpdates/watermark",
  meta: {
    icon: "icon-ota-updates",
    title: $t("menus.otaUpdates"),
    rank: otaUpdate
  }
} as RouteConfigsTable;
